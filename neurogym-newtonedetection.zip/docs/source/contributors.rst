************
Contributors
************

This is an open source project, and we welcome any form of contribution. We
are a growing team of people who contribute to the NeuroGym project in their
spare time. Please contact Manuel Molano or Guangyu Robert Yang if you are
interested in contributing, or simply send a pull request to our github repo.

Here is a list of contributors in chronological order.

`Marta Fradera <https://github.com/martafradera>`_, `Jordi Pastor
<https://github.com/pastorjordi>`_, `Jeremy
Forest <https://github.com/jeremyforest>`_, `Ru-Yuan Zhang <https://github.com/ruyuanzhang>`_