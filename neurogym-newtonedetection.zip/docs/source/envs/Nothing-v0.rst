Nothing-v0
--------------------------------------------------
.. autoclass:: neurogym.envs.nothing.Nothing
    :members:
    :exclude-members: new_trial

    Reference paper
        `Prefrontal cortex as a meta-reinforcement learning system <https://www.nature.com/articles/s41593-018-0147-8>`__

    Tags
        :ref:`tag-n-alternative`,         :ref:`tag-supervised`

    Sample run
        .. image:: images/Nothing-v0_examplerun.png
            :width: 600

