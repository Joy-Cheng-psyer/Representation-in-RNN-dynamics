"""Test collections of tasks."""

